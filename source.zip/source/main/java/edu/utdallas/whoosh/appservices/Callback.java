package edu.utdallas.whoosh.appservices;

/**
 * Created by sasha on 11/28/15.
 */
public interface Callback {
    void call(boolean success);
}
