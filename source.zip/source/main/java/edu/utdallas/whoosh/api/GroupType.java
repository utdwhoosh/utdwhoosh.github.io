package edu.utdallas.whoosh.api;

/**
 * An enumeration listing the various types of {@link //NodeGroup}s.
 *
 * Created by sasha on 9/22/15.
 */
public enum GroupType {

    Building,
    OutdoorArea,
    ;

}