This application and documentation was created by Team Whoosh, as the semester project in SE-4351, taught by Dr. Lawrence Chung in the Fall semester of 2015.



Contents
========

1. app-debug.apk - Android application deployable package
2. Phase I Presentation.pdf
3. Phase II Presentation.pdf
4. PMP.pdf
5. src - Android application source code
6. Vision.pdf
7. WRS.pdf



Website
=======

http://utdwhoosh.github.io




Team Members (in alphabetical order)
====================================

Sasha Borodin
axb138330
sasha@borodin.info

Luke Carr
lxc112230
luke.carr4@gmail.com

Izuchukwu Elechi
ixe120130
izuchukwu@utdallas.edu

Dustin Endres
dxe110630
dxe110630@utdallas.edu

Dustin Grannemann
dsg101020
dsg101020@utdallas.edu

Thomas Grice
tag130230
augustus.grice@gmail.com

Taber Hust
txh120330
txh120330@utdallas.edu

Marie Imperial
fxi120030
fxi120030@utdallas.edu

Jessica Jennings
jmj112020
jmj112020@utdallas.edu

Elise Keller
exk120130
exk120130@utdallas.edu

Jacinth “Jason” Nguyen
jrn120030
jrn120030@utdallas.edu

Tayaba Saleem
txs121430
txs121430@utdallas.edu

Kesha Shrestha
kxs135430
kxs135430@utdallas.edu

Maelene Tacata
mxt125730
mxt125730@utdallas.edu